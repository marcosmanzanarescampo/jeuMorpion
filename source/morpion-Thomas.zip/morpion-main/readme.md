- Plateau de jeu 
    3 x 3

- Pion à placer 
    Croix
    Rond

- Conditions de victoire
    Dès qu'il y a 3 signes identiques, le joueur gagne la partie

- Le changement de joueur 
    Après avoir placé un pion, un changement de joueur se fait
    Afficher le tour du joueur actif

- Un seul pion par case
    Il faut faire attention à bien vérifier si la case n'est pas occupé
- Conditions d'égalité
    Si le plateau est rempli et qu'il n'y a pas 3 pions identiques d'aligné, il y a égalité

- Déclenchement / reset de partie 
    Un bouton pour déclencher une partie et reset une partie

